-- Add notes field to vehicles table
ALTER TABLE public.vehicles ADD COLUMN notes text;