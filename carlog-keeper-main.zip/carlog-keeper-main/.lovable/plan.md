
# QR Kod Eşleştirme Sistemi Planı

## Özet
Mevcut QR kodlarınızdaki benzersiz içerikleri (ör: "https://umit.oto.slot2601") veritabanında saklanacak şekilde bir eşleştirme sistemi oluşturulacak. QR taratıldığında bu içerik aranacak ve doğru slot ile eşleştirilecek.

---

## Yapılacak Değişiklikler

### 1. Veritabanı Güncellemesi
Yeni bir `qr_mappings` tablosu oluşturulacak:

- `id` - Benzersiz kayıt ID'si
- `slot_number` - Slot numarası (1-100 arası)
- `qr_content` - QR kodun içindeki tam metin (ör: "https://umit.oto.slot2601")
- `created_at` - Oluşturulma tarihi

Bu şekilde bir QR taratıldığında önce bu tabloda aranacak, içerik bulunursa ilgili slot numarasına yönlendirilecek.

---

### 2. QR Yönetim Paneli Güncellemesi
Her slot için yeni bir "QR İçeriği Kaydet" butonu eklenecek:

- Slot üzerinde QR görseli varken veya yokken de kullanılabilir
- Manuel olarak QR içeriğini yazabilirsiniz
- Veya isterseniz QR'ı telefonla taratıp içeriği kopyalayabilirsiniz

---

### 3. QR Tarama Sayfası Güncellemesi
Tarama algoritması şu sırayla çalışacak:

```
1. QR taratıldı → "https://umit.oto.slot2601"
2. Önce qr_mappings tablosunda ara
3. Eşleşme bulundu → slot_number = 1
4. vehicles tablosunda qr_code = "1" olan aracı getir
5. Araç detay sayfasına yönlendir
```

---

### 4. Toplu QR Kayıt Özelliği (Opsiyonel)
QR Yönetim panelinde toplu kayıt için:

- Başlangıç numarası girin (ör: 2601)
- Tüm slotlar için otomatik format oluştur
- Format: `https://umit.oto.slot{başlangıç + slot - 1}`

---

## Düzenlenecek Dosyalar

| Dosya | Değişiklik |
|-------|-----------|
| Veritabanı | Yeni `qr_mappings` tablosu oluştur |
| `src/pages/QRManagement.tsx` | QR içeriği kaydetme alanı ekle |
| `src/pages/ScanQRDebug.tsx` | Önce qr_mappings tablosunu kontrol et |

---

## Teknik Detaylar

### Veritabanı Şeması
```sql
CREATE TABLE qr_mappings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slot_number INTEGER NOT NULL UNIQUE,
  qr_content TEXT NOT NULL UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);
```

### Tarama Algoritması
```typescript
// 1. QR içeriğini qr_mappings tablosunda ara
const { data: mapping } = await supabase
  .from("qr_mappings")
  .select("slot_number")
  .eq("qr_content", scannedContent)
  .maybeSingle();

// 2. Eşleşme bulunduysa slot numarasını al
if (mapping) {
  const slotNumber = mapping.slot_number.toString();
  // 3. Bu slot numarasına kayıtlı aracı bul
  const { data: vehicle } = await supabase
    .from("vehicles")
    .select("id")
    .eq("qr_code", slotNumber)
    .maybeSingle();
}
```

---

## Kullanım Senaryosu

1. QR Yönetim panelini açın
2. Slot 1'in yanındaki "QR İçeriği" alanına `https://umit.oto.slot2601` yazın
3. Kaydet'e tıklayın
4. Artık bu QR taratıldığında Slot 1'deki araca yönlendirileceksiniz
